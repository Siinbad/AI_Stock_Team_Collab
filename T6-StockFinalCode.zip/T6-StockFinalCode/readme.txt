This is the final code of T6-Stock Bot

To run the code, open the UpdatedGUI_2 file. This is a custom GUI that is integrated with our fine tuned model