import openai


openai.api_key = "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"


def write_prompt(textbox):
    prompt = textbox
    response = openai.Completion.create(
        engine="davinci:ft-personal-2023-04-14-16-03-22",
        prompt=prompt,
        temperature=.4,
        max_tokens=64
    )
    print(response)
    return response
